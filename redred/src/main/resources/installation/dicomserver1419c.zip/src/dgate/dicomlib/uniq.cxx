/*
19990511    ljz    Fix: All routines wrongly used '%' instead of '&'
*/
/****************************************************************************
          Copyright (C) 1995, University of California, Davis

          THIS SOFTWARE IS MADE AVAILABLE, AS IS, AND THE UNIVERSITY
          OF CALIFORNIA DOES NOT MAKE ANY WARRANTY ABOUT THE SOFTWARE, ITS
          PERFORMANCE, ITS MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR
          USE, FREEDOM FROM ANY COMPUTER DISEASES OR ITS CONFORMITY TO ANY
          SPECIFICATION. THE ENTIRE RISK AS TO QUALITY AND PERFORMANCE OF
          THE SOFTWARE IS WITH THE USER.

          Copyright of the software and supporting documentation is
          owned by the University of California, and free access
          is hereby granted as a license to use this software, copy this
          software and prepare derivative works based upon this software.
          However, any distribution of this software source code or
          supporting documentation or derivative works (source code and
          supporting documentation) must include this copyright notice.
****************************************************************************/

/***************************************************************************
 *
 * University of California, Davis
 * UCDMC DICOM Network Transport Libraries
 * Version 0.1 Beta
 *
 * Technical Contact: mhoskin@ucdavis.edu
 *
 ***************************************************************************/

/*************************************************************************

 * Unique ID's.  Gurenteed to be unique in any given association, but not

 * across multple associations.

 ************************************************************************/

#	include	"dicom.hpp"



static unsigned	long	uniqid = 1;



UINT	uniq()
{
	return(uniqid++);
}


UINT32	uniq32()
{
	return(uniqid++);
}


UINT16	uniq16()
{
	return(UINT16)((uniqid++) & 0xffff);
}



UINT8	uniq8()
{
	return(UINT8)((uniqid++) & 0xff);
}


UINT8	uniq8odd()
{
	if(uniqid & 0x01)
		return(UINT8)((uniqid++) & 0xff);
	++uniqid;
	return(UINT8)((uniqid++) & 0xff);
}


UINT16	uniq16odd()
{
	if(uniqid & 0x01)
		return(UINT16)((uniqid++) & 0xffff);
	++uniqid;
	return(UINT16)((uniqid++) & 0xffff);
}

