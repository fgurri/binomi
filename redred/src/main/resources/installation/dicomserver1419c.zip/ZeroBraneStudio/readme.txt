This folder contains all files necessary to enable editing and debugging [Lua](http://www.lua.org) 
scripts for [Conquest Dicom Server](http://ingenium.home.xs4all.nl/dicom.html) (`V 1.4.17alpha up`) in the fantastic [ZeroBrane Studio](http://studio.zerobrane.com) (`V 0.35 up`) development environment. 

Use as follows: 

Open **ZeroBrane Studio** and look at the `Local console` tab
Load the install.lua file with     `File - Open`
Select all text using              `right-click - Select All`
Run it in the console using        `right-click - Evaluate in Console`

After this - ZeroBrane Studio will reopen ready to run demo scripts 
and develop for **Conquest Dicom Server**. As installed, Zerobrane Studio
communicates with a running Conquest Dicom Server and offers code 
completion and full debugging facilities. 
