local a, b = dofile('interpreters/conquestdicomserver.lua')
return b
