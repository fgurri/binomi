Place lua external libraries here such as CD and IUP for use within the DICOM server.
To work also place a lua 5.1.4 dll here.

For 64 bits windows use:

cd-5.4.1_Win64_dll8_lib.zip
iup-3.5_Win64_dll8_lib.zip
lua-5.1.4_Win64_dll10_lib.zip

For 32 bits windows use:

cd-5.4.1_Win32_dll8_lib.zip
iup-3.5_Win32_dll8_lib.zip
lua-5.1.4_Win32_dll10_lib.zip

