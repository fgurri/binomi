-- test version 20120719

HTML('Content-type: text/plain\n\n');
print(servercommand('status_string:'));

